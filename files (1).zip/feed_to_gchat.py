#!/usr/bin/env python3
"""Post new items from RSS/Atom feeds (status pages, release news) to Google Chat."""
import html
import json
import os
import re
import sys
from pathlib import Path

import feedparser
import requests

WEBHOOK = os.environ.get("GCHAT_WEBHOOK_URL", "")
DRY_RUN = os.environ.get("DRY_RUN") == "1"          # print instead of posting
STATE_FILE = Path(__file__).with_name("state.json")
MAX_PER_FEED = 5       # safety cap per run, avoids floods
SUMMARY_LEN = 220
KEEP_SEEN = 300

# kind="status": incident feeds (Statuspage). Message shows Investigating/Resolved etc.
# kind="news":   release/news feeds. Message shows the `label`.
FEEDS = [
    {"name": "GitHub Status",     "url": "https://www.githubstatus.com/history.rss",       "kind": "status"},
    {"name": "Cloudflare Status", "url": "https://www.cloudflarestatus.com/history.rss",   "kind": "status"},
    {"name": "Shopify Status",    "url": "https://www.shopifystatus.com/history.rss",      "kind": "status"},  # verify URL
    {"name": "WordPress News",    "url": "https://wordpress.org/news/feed/",               "kind": "news", "label": "New post"},
    {"name": "PHP Releases",      "url": "https://www.php.net/releases/feed.php",          "kind": "news", "label": "New release"},
    {"name": "PHP News",          "url": "https://www.php.net/feed.atom",                  "kind": "news", "label": "News"},
    {"name": "Shopify Changelog", "url": "https://shopify.dev/changelog/feed.xml",         "kind": "news", "label": "Changelog"},
    # Add more here, e.g. WooCommerce, Laravel News, Node.js, Patchstack...
]

STATUS_STYLE = {
    "investigating": ("🔴", "Investigating"),
    "identified":    ("🟠", "Identified"),
    "monitoring":    ("🟡", "Monitoring"),
    "verifying":     ("🟡", "Verifying"),
    "resolved":      ("🟢", "Resolved"),
    "completed":     ("🟢", "Completed"),
    "scheduled":     ("🔧", "Scheduled maintenance"),
    "in progress":   ("🔧", "Maintenance in progress"),
    "update":        ("🔵", "Update"),
}
STATUS_RE = re.compile(
    r"<strong>\s*(Investigating|Identified|Monitoring|Verifying|Resolved|Completed|"
    r"Scheduled|In progress|Update)\s*</strong>\s*-\s*(.*?)(?=<br|$)",
    re.I | re.S,
)


def clean(text: str) -> str:
    text = re.sub(r"<[^>]+>", " ", text or "")
    return re.sub(r"\s+", " ", html.unescape(text)).strip()


def shorten(text: str, n: int = SUMMARY_LEN) -> str:
    return text if len(text) <= n else text[: n - 1].rsplit(" ", 1)[0] + "…"


def entry_key(feed: dict, e) -> str:
    base = e.get("id") or e.get("link") or e.get("title", "")
    if feed["kind"] == "status":  # incident updates change `updated`, so re-alert
        return f"{base}|{e.get('updated', '')}"
    return base


def build_message(feed: dict, e) -> str:
    title = clean(e.get("title", "(no title)"))
    link = e.get("link", "")
    raw = e.get("summary") or e.get("description") or ""

    if feed["kind"] == "status":
        m = STATUS_RE.search(raw)
        if m:
            emoji, label = STATUS_STYLE[m.group(1).lower()]
            summary = clean(m.group(2))
        else:
            emoji, label, summary = "🔵", "Update", clean(raw)
    else:
        emoji, label, summary = "🆕", feed.get("label", "Update"), clean(raw)

    lines = [f"{emoji} *{feed['name']}* · {label}", f"*{title}*"]
    if summary:
        lines.append(shorten(summary))
    if link:
        lines.append(f"<{link}|Read more>")
    return "\n".join(lines)


def post(text: str) -> bool:
    if DRY_RUN:
        print("--- DRY RUN ---\n" + text + "\n")
        return True
    try:
        r = requests.post(WEBHOOK, json={"text": text}, timeout=15)
        r.raise_for_status()
        return True
    except requests.RequestException as ex:
        print(f"  post failed: {ex}", file=sys.stderr)
        return False


def main() -> int:
    if not WEBHOOK and not DRY_RUN:
        print("GCHAT_WEBHOOK_URL is not set", file=sys.stderr)
        return 1

    state = json.loads(STATE_FILE.read_text()) if STATE_FILE.exists() else {}

    for feed in FEEDS:
        name = feed["name"]
        try:
            resp = requests.get(feed["url"], timeout=20,
                                headers={"User-Agent": "dev-team-feed-bot/1.0"})
            resp.raise_for_status()
            parsed = feedparser.parse(resp.content)
        except requests.RequestException as ex:
            print(f"[{name}] fetch failed: {ex}", file=sys.stderr)
            continue
        if not parsed.entries:
            print(f"[{name}] no entries found (check URL)", file=sys.stderr)
            continue

        keys = [entry_key(feed, e) for e in parsed.entries]

        # First time we see a feed: remember what exists, don't spam old items.
        if name not in state:
            state[name] = keys[:KEEP_SEEN]
            print(f"[{name}] first run, seeded {len(keys)} items")
            continue

        seen = set(state[name])
        new = [(k, e) for k, e in zip(keys, parsed.entries) if k not in seen]
        new.reverse()  # oldest first
        print(f"[{name}] {len(new)} new")

        for k, e in new[-MAX_PER_FEED:]:
            if post(build_message(feed, e)):
                state[name].insert(0, k)
        # items beyond the cap are marked seen so they don't repost next run
        for k, _ in new[:-MAX_PER_FEED]:
            state[name].insert(0, k)
        state[name] = state[name][:KEEP_SEEN]

    STATE_FILE.write_text(json.dumps(state, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
